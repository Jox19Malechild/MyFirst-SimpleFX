import java.io.*;
import java.util.*;
import java.util.logging.*;

/**
 * ICT261 Unit 4 Lab - Exception Handling and Error Management
 * Name: Kabunda Jacques | Student No: 202510287
 *
 * DECISION (skip or stop?): ONE BAD RECORD IS SKIPPED, the import continues.
 * Reason: a single wrong line (e.g. "ABC" as a mark) should not stop the
 * other valid students from being imported. Each bad line is reported to the
 * user in a friendly way, the technical cause goes to the log file, and a
 * summary of accepted / rejected records is shown at the end.
 * (A missing file is different: nothing can be imported, so we stop.)
 */

/** Custom UNCHECKED exception: extends RuntimeException, thrown for repeated student IDs. */
class DuplicateStudentException extends RuntimeException {
    private final String studentId;

    public DuplicateStudentException(String studentId) {
        super("Duplicate student number: " + studentId);
        this.studentId = studentId;
    }

    public String getStudentId() {
        return studentId;
    }
}

public class MarksImporter {

    private static final Logger LOGGER = Logger.getLogger(MarksImporter.class.getName());

    // Change this to "absent.txt" to run test T5 (or pass the file name as a program argument).
    private static final String DEFAULT_FILE = "marks.txt";

    /** Technical details go to the log FILE only; the console is for friendly messages. */
    private static void setupLogger() {
        try {
            LOGGER.setUseParentHandlers(false);              // no technical text on the console
            FileHandler fh = new FileHandler("marks_import.log", true);
            fh.setFormatter(new SimpleFormatter());
            LOGGER.addHandler(fh);
        } catch (IOException e) {
            System.out.println("Warning: log file could not be created.");
        }
    }

    static void importMarks(String filename) throws IOException {
        Set<String> seen = new HashSet<>();
        int accepted = 0;
        int rejected = 0;
        int lineNo = 0;

        // try-with-resources: the BufferedReader (and the FileReader inside it) is
        // closed AUTOMATICALLY when the block ends, whether it ends normally or
        // because an exception was thrown, so there is no need for br.close() in finally.
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null) {
                lineNo++;
                if (line.trim().isEmpty()) {
                    continue; // ignore blank lines
                }
                try {
                    String[] parts = line.split(",");

                    // TODO 1: check there are exactly 2 fields
                    if (parts.length != 2) {
                        throw new IllegalArgumentException(
                                "Expected 2 fields (ID, mark) but found " + parts.length);
                    }
                    String id = parts[0].trim();
                    if (id.isEmpty()) {
                        throw new IllegalArgumentException("Student number is empty");
                    }

                    // TODO 2: parse mark and validate range 0..100
                    int mark = Integer.parseInt(parts[1].trim()); // may throw NumberFormatException
                    if (mark < 0 || mark > 100) {
                        throw new IllegalArgumentException("Mark " + mark + " is outside the range 0..100");
                    }

                    // TODO 3: detect repeated student ID using seen
                    if (seen.contains(id)) {
                        throw new DuplicateStudentException(id);
                    }
                    seen.add(id);

                    // TODO 4: display accepted record
                    System.out.println("Accepted: " + id + " -> " + mark);
                    accepted++;

                } catch (NumberFormatException e) {
                    rejected++;
                    System.out.println("Line " + lineNo + " skipped: the mark is not a valid number ("
                            + line.trim() + ")");
                    LOGGER.log(Level.WARNING, "Line " + lineNo + ": " + e.getClass().getName()
                            + " - " + e.getMessage());
                } catch (DuplicateStudentException e) {
                    rejected++;
                    System.out.println("Line " + lineNo + " skipped: student " + e.getStudentId()
                            + " already imported (duplicate)");
                    LOGGER.log(Level.WARNING, "Line " + lineNo + ": " + e.getClass().getName()
                            + " - " + e.getMessage());
                } catch (IllegalArgumentException e) {
                    rejected++;
                    System.out.println("Line " + lineNo + " skipped: " + e.getMessage());
                    LOGGER.log(Level.WARNING, "Line " + lineNo + ": " + e.getClass().getName()
                            + " - " + e.getMessage());
                }
            }
        }
        System.out.println("Summary: " + accepted + " accepted, " + rejected + " rejected.");
    }

    public static void main(String[] args) {
        setupLogger();
        String filename = args.length > 0 ? args[0] : DEFAULT_FILE;

        try {
            importMarks(filename);

        } catch (FileNotFoundException e) {          // MUST come before IOException (more specific first)
            System.out.println("Marks file not found; check the file name.");
            LOGGER.log(Level.SEVERE, e.getClass().getName() + " - " + e.getMessage(), e);

        } catch (IOException e) {                    // any other read/write problem
            System.out.println("A problem occurred while reading the file. Please try again.");
            LOGGER.log(Level.SEVERE, e.getClass().getName() + " - " + e.getMessage(), e);

        } catch (DuplicateStudentException e) {      // safety net: normally handled per record (skip strategy)
            System.out.println("Duplicate student number found: " + e.getStudentId());
            LOGGER.log(Level.WARNING, e.getClass().getName() + " - " + e.getMessage(), e);

        } catch (IllegalArgumentException e) {       // safety net for invalid data
            System.out.println("Invalid data found in the marks file.");
            LOGGER.log(Level.WARNING, e.getClass().getName() + " - " + e.getMessage(), e);

        } finally {
            System.out.println("Import attempt finished");
        }
    }
}
